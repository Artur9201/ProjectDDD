package hello.repository;

import hello.model.dto.UserDto;

import java.util.List;

public interface UserService {
    UserDto getUserById(Integer userId);
    void saveUser(UserDto userDto);
    List< UserDto > getAllUsers();
}